package org.adaschool.Booking.Bus.Travel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingBusTravelApplicationTests {

	@Test
	void contextLoads() {
	}

}
