package org.adaschool.Booking.Bus.Travel.Controller;


import org.adaschool.Booking.Bus.Travel.Domain.Dto.bookingDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.adaschool.Booking.Bus.Travel.bookingService;


import java.util.List;

@RestController
@RequestMapping("/api/v1//booking")
public class bookingController {
    private final bookingService<bookingDto> bookingService;

    public bookingController(bookingService<bookingDto> bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping()
    public ResponseEntity<?> saveBooking(@RequestBody bookingDto bookingDto) {
        bookingService.save(bookingDto);
        return new ResponseEntity<>("save", HttpStatus.CREATED);
    }

    @GetMapping("list")
    public ResponseEntity<?> getAllBookings(){
        List<bookingDto> bookings = bookingService.findAll();
        return new ResponseEntity<>(bookings, HttpStatus.FOUND);

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBooking(@PathVariable("id") Integer id)
            throws Exception {
        bookingService.delete(Integer.valueOf(id.toString()));
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

