package org.adaschool.Booking.Bus.Travel.Mapper.Base;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;


@Mapper
public interface mapperBase {
    mapperBase INSTANCE = Mappers.getMapper(mapperBase.class);
}
