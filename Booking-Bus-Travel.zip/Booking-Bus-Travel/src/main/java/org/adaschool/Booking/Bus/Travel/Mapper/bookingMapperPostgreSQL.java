package org.adaschool.Booking.Bus.Travel.Mapper;

import org.adaschool.Booking.Bus.Travel.Domain.Dto.bookingDto;
import org.adaschool.Booking.Bus.Travel.Domain.Entity.bookingPostgreSQL;
import org.adaschool.Booking.Bus.Travel.Mapper.Base.mapperBase;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

public interface bookingMapperPostgreSQL extends mapperBase {
    @Mapping(source = "id", target = "id", qualifiedByName = "objectToInteger")
    bookingPostgreSQL toEntity(bookingDto dto);
    bookingDto toDto(bookingPostgreSQL entity);
    List<bookingPostgreSQL> toEntityList(List<bookingDto> dtoList);
    List<bookingDto> toDtoList(List<bookingPostgreSQL> entityList);
    @Named("objectToInteger")
    default Integer objectToInteger(Object obj){
        return Integer.valueOf(obj.toString());
    }
}
