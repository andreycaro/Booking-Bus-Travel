package org.adaschool.Booking.Bus.Travel.Domain.Dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.adaschool.Booking.Bus.Travel.Domain.Entity.bookingMongoDB;

import java.time.LocalDate;
import java.time.LocalTime;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record bookingDto(
        Object id,
        String name,
        String email,
        String origin,
        String destination,
        LocalDate departureDate,
        LocalTime departureTime,
        String duration
)  {
}
