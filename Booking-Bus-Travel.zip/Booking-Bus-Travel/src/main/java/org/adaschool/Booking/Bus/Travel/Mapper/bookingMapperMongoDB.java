package org.adaschool.Booking.Bus.Travel.Mapper;

import org.adaschool.Booking.Bus.Travel.Domain.Dto.bookingDto;
import org.adaschool.Booking.Bus.Travel.Domain.Entity.bookingMongoDB;
import org.adaschool.Booking.Bus.Travel.Mapper.Base.mapperBase;
import org.mapstruct.Mapping;
import org.mapstruct.Named;


import java.util.List;

public interface bookingMapperMongoDB extends mapperBase {
    @Mapping(source = "id", target = "id", qualifiedByName = "objectToString")
    bookingMongoDB toEntity(bookingDto dto);
    bookingDto toDto(bookingMongoDB dto);
    List<bookingMongoDB> toEntityList(List<bookingDto> dtoList);
    List<bookingDto> toDtoList(List<bookingMongoDB> entityList);
    @Named("objectToString")
    default String objectToString(Object obj) { return obj.toString(); }

}
