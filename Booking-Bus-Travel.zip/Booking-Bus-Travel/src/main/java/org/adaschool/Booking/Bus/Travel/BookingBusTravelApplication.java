package org.adaschool.Booking.Bus.Travel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingBusTravelApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingBusTravelApplication.class, args);
	}

}
