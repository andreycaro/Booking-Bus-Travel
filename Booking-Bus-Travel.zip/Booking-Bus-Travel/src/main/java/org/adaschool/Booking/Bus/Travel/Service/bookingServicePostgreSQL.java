package org.adaschool.Booking.Bus.Travel.Service;

import org.adaschool.Booking.Bus.Travel.Domain.Dto.bookingDto;
import org.adaschool.Booking.Bus.Travel.Mapper.bookingMapperPostgreSQL;
import org.adaschool.Booking.Bus.Travel.Domain.Entity.bookingPostgreSQL;
import org.adaschool.Booking.Bus.Travel.bookingService;
import org.adaschool.Booking.Bus.Travel.Domain.Repository.bookingPostgreSQLRepository;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class bookingServicePostgreSQL implements bookingService<bookingDto> {
    private final bookingPostgreSQLRepository bookingPostgreSQLRepository;
    private final bookingMapperPostgreSQL mapper;

    public bookingServicePostgreSQL(bookingPostgreSQLRepository bookingPostgreSQLRepository, bookingMapperPostgreSQL mapper) {
        this.bookingPostgreSQLRepository = bookingPostgreSQLRepository;
        this.mapper = mapper;
    }

    @Override
    public void save(bookingDto dto) {
        bookingPostgreSQL bookingPostgreSQL = mapper.toEntity(dto);
        bookingPostgreSQLRepository.save(bookingPostgreSQL);

    }

    @Override
    public bookingDto findById(Object id) throws Exception {
        bookingPostgreSQL bookingPostgreSQL = bookingPostgreSQLRepository.findById(Integer.valueOf(id.toString()))
                .orElseThrow(() -> new Exception("Data not found"));
        return mapper.toDto(bookingPostgreSQL);
    }

    @Override
    public List<bookingDto> findAll() {
        List<bookingPostgreSQL> bookings = bookingPostgreSQLRepository.findAll();
        return mapper.toDtoList(bookings);
    }
    @Override
    public void delete(Object id) {
        bookingPostgreSQLRepository.deleteById(Integer.valueOf(id.toString()));

    }
}
