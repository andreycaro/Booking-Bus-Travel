package org.adaschool.Booking.Bus.Travel.Domain.Repository;

import org.adaschool.Booking.Bus.Travel.Domain.Entity.bookingMongoDB;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface bookingMongoDBRepository extends MongoRepository<bookingMongoDB, String> {
}
