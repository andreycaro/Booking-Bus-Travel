package org.adaschool.Booking.Bus.Travel.Domain.Repository;

import org.adaschool.Booking.Bus.Travel.Domain.Entity.bookingPostgreSQL;
import org.springframework.data.jpa.repository.JpaRepository;

public interface bookingPostgreSQLRepository extends JpaRepository<bookingPostgreSQL, Integer> {
}
