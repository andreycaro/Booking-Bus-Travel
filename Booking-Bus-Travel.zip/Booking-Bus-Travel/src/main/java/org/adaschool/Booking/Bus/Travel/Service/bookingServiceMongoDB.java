package org.adaschool.Booking.Bus.Travel.Service;

import org.adaschool.Booking.Bus.Travel.Domain.Dto.bookingDto;
import org.adaschool.Booking.Bus.Travel.Domain.Entity.bookingMongoDB;
import org.adaschool.Booking.Bus.Travel.Mapper.bookingMapperMongoDB;
import org.adaschool.Booking.Bus.Travel.bookingService;
import org.adaschool.Booking.Bus.Travel.Domain.Repository.bookingMongoDBRepository;


import java.util.List;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

public class bookingServiceMongoDB  implements bookingService<bookingDto> {
   private final bookingMongoDBRepository bookingMongoDBRepository;
   private final bookingMapperMongoDB mapper;
   public bookingServiceMongoDB(bookingMongoDBRepository bookingMongoDBRepository, bookingMapperMongoDB mapper){
       this.bookingMongoDBRepository = bookingMongoDBRepository;
       this.mapper =mapper;
   }
    @Override
    public void save(bookingDto dto) {
        bookingMongoDB bookingMongoDB = mapper.toEntity(dto);
        bookingMongoDBRepository.save(bookingMongoDB);
   }

    @Override
    public bookingDto findById(Object id) throws Exception {
        bookingMongoDB bookingMongoDB = bookingMongoDBRepository.findById(id.toString())
                .orElseThrow(() -> new Exception("Data not found"));
        return mapper.toDto(bookingMongoDB);
   }
   @Override
   public List<bookingDto> findAll() {
       List<bookingMongoDB> bookings = bookingMongoDBRepository.findAll();
       return mapper.toDtoList(bookings);
   }
   @Override
   public void delete(Object id){
       bookingMongoDBRepository.deleteById(id.toString());
        }
}
